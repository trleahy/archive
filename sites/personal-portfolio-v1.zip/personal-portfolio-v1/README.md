This repo contains the source code for my personal portfolio.

If you're not me and you have a question, you can contact me using the form [here](https://oblivionmedia.typeform.com/to/EwQYqmPa).
***
![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/trleahy/Personal-Portfolio/pages.yml?style=flat-square)
![GitHub last commit](https://img.shields.io/github/last-commit/trleahy/Personal-Portfolio?style=flat-square)
